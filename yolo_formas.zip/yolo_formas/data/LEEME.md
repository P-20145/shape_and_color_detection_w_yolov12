# Carpeta data/

Aqui debe quedar el dataset ya filtrado, con esta forma exacta:

```
data/shapes3b/
├── train/images  train/labels
├── valid/images  valid/labels
└── test/images   test/labels
```

Como obtenerlo: ver la seccion **Dataset** del README (opcion A: zip exportado desde Colab; opcion B: `prepare_data.py`).

No hace falta crear el `data.yaml` a mano: los scripts lo generan con la ruta correcta de este equipo.
